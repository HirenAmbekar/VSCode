﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Experiment9
{
    class Program
    {
        static void Main(string[] args)
        {
            //For write into the File 
            using (StreamWriter s = new StreamWriter("C:\\Users\\HP\\Desktop\\file.txt"))
            {
                s.WriteLine("Hello, The file created using the StreamWriter class ");
                s.Close();
            }
            Console.WriteLine("Data Sucessfully inserted into the file.txt");

            // For read data from the file
            Console.WriteLine("Data:");
            using(StreamReader r = new StreamReader("C:\\Users\\HP\\Desktop\\file.txt"))
            {
                Console.Write(r.ReadToEnd());
            }

            Console.ReadKey();
        }
    }
}
